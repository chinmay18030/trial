from trial import me
from trial import world
